package bai2;

import java.util.ArrayList;
import java.util.Scanner;

import bai1.laptrinhvien;
import bai1.nhanvientesting;
import bai1.quanlytruong;

public class mainrun {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        // Nhap
        ArrayList<product> arr = new ArrayList<product>();
        phone p;
        laptop l;
        
        int choose;
        do {
            System.out.print("Chon thao tac: ");
            System.out.print(" 1.Them 1 phone moi ");
            System.out.print(" 2.Them 1 laptop moi ");
            System.out.print(" 3.In danh sach nhung laptop co gia ban cao nhat");
            System.out.println(" 0.Thoat");
            choose = sc.nextInt();
            switch (choose) {
                case 1:
                    p=new phone();
                    p.nhap_phone();
                    arr.add(p);
                    break;
                case 2:
                    l=new laptop();
                    l.nhap_laptop();
                    arr.add(l);
                    break;
                case 3:
                    inDanhSach(arr);
                    break;
                  
                default:
                   System.out.println("Tam biet.");;
            }
        } while (choose != 0);
        sc.close();
    }
    public static void inDanhSach(ArrayList<product> arr) {
        ArrayList<product>ds=new ArrayList<product>(); 
        if (arr.isEmpty()) {
            System.out.println("Danh sach san pham rong.");
        } else {
            System.out.println("Danh sach laptop co gia ban cao nhat:");
            product l1=new laptop();
            for (product sp : arr) {
                if(sp.giaban()>l1.giaban()&&sp instanceof laptop){
                    l1=sp;
                }    
            }
            for (product sp : arr) {
                if(sp.giaban()==l1.giaban()&&sp instanceof laptop){
                    ds.add(sp);
                }    
            }
            for (product sp : ds) {
                
                    System.out.println(sp.toString());
            
            }
            
        }
    }
}
