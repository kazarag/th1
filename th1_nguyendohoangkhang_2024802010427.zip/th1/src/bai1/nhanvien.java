package bai1;

import java.util.Scanner;

class nhanvien {
    int mnv;
    String hoten;

    public nhanvien() {
        super();
    }

    public nhanvien(int mnv, String hoten) {
        super();
        this.mnv = mnv;
        this.hoten = hoten;
    }

    public int getMnv() {
        return mnv;
    }

    public void setMnv(int mnv) {
        this.mnv = mnv;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public void nhap_nhanvien() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap ma nhan vien: ");
        this.mnv = sc.nextInt();
        sc.nextLine();
        System.out.print("Nhap ho ten: ");
        this.hoten = sc.nextLine();
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return this.mnv + "\t" + this.hoten;
    }
}
