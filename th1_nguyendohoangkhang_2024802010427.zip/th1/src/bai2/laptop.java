package bai2;

import java.util.Scanner;

public class laptop extends product {
    int sothangbaohanh;

    public laptop() {
        super();
    }

    public laptop(int masp, String tensp, int sothangbaohanh) {
        super(masp, tensp, sothangbaohanh);
        this.sothangbaohanh = sothangbaohanh;
        // TODO Auto-generated constructor stub
    }

    public int getsothangbaohanh() {
        return sothangbaohanh;
    }

    public void setsothangbaohanh(int sothangbaohanh) {
        this.sothangbaohanh = sothangbaohanh;
    }

    public void nhap_laptop() {
        Scanner sc = new Scanner(System.in);
        nhap_sp();
        System.out.print("Nhap so thang bao hanh: ");
        this.sothangbaohanh = sc.nextInt();
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "Laptop: "+super.toString() + "\t" + " So thang bao hanh:" + this.sothangbaohanh+"\t"+giaban();
    }

    @Override
    double giaban() {
        // TODO Auto-generated method stub
        return this.giagoc + this.sothangbaohanh * 100000;
    }
}
