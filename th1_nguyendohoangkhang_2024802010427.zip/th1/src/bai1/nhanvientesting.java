package bai1;

import java.util.Scanner;

public class nhanvientesting extends nhanvien {
    String loaikiemthu;

    public nhanvientesting() {
        super();
    }

    public nhanvientesting(int mnv, String hoten, String loai) {
        super(mnv, hoten);
        this.loaikiemthu = loai;
        // TODO Auto-generated constructor stub
    }

    public String getLoaikiemthu() {
        return loaikiemthu;
    }

    public void setLoaikiemthu(String loaikiemthu) {
        this.loaikiemthu = loaikiemthu;
    }

    public void nhap_NVTesting() {
        Scanner sc = new Scanner(System.in);
        nhap_nhanvien();
        System.out.print("Nhap loai kiem thu: ");
        this.loaikiemthu = sc.nextLine();
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return super.toString() + "\t"+" Loai kiem thu:" + this.loaikiemthu;
    }
}
