package bai1;

import java.util.Scanner;

public class quanlytruong extends nhanvien {
    int capbac;

    public quanlytruong() {
        super();
    }

    public quanlytruong(int mnv, String hoten, int cap) {
        super(mnv, hoten);
        this.capbac = cap;
        // TODO Auto-generated constructor stub
    }

    public int getCapbac() {
        return capbac;
    }

    public void setCapbac(int capbac) {
        this.capbac = capbac;
    }

    public void nhap_QL() {
        Scanner sc = new Scanner(System.in);
        nhap_nhanvien();
        System.out.print("Nhap cap bac quan ly (1-5): ");
        this.capbac = sc.nextInt();
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return super.toString() + "\t"+" Cap bac:" + this.capbac;
    }
}