package bai1;

import java.util.ArrayList;
import java.util.Scanner;

public class mainrun {

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        // Nhap
        ArrayList<nhanvien> arr = new ArrayList<nhanvien>();
        laptrinhvien ltv;
        quanlytruong ql;
        nhanvientesting testing;
        int mnv;
        int choose;
        do {
            System.out.print("Chon thao tac: ");
            System.out.print("1. Them quan ly truong ");
            System.out.print("2. Them nhan vien testing ");
            System.out.print("3. Them lap trinh vien ");
            System.out.print(" 4. In danh sach");
            System.out.print(" 5. Tim thanh vien");
            System.out.println(" 6. Thoat");
            choose = sc.nextInt();
            switch (choose) {
                case 1:
                    ql = new quanlytruong();
                    ql.nhap_QL();
                    arr.add(ql);
                    break;
                case 2:
                    testing = new nhanvientesting();
                    testing.nhap_NVTesting();
                    arr.add(testing);
                    break;
                case 3:
                    ltv = new laptrinhvien();
                    ltv.nhap_LTV();
                    arr.add(ltv);
                    break;

                case 4:
                    inDanhSach(arr);
                    break;
                case 5:
                    mnv = sc.nextInt();
                    timThanhVien(arr, mnv);
                    break;
                case 6:
                    System.out.println("tam biet");
                    break;
                default:
                    System.out.println("Lua chon khong hop le. Vui long chon lai.");
            }
        } while (choose != 6);
        sc.close();
    }

    public static void inDanhSach(ArrayList<nhanvien> arr) {
        if (arr.isEmpty()) {
            System.out.println("Danh sach thanh vien rong.");
        } else {
            System.out.println("Danh sach thanh vien:");

            for (nhanvien thanhVien : arr) {

                System.out.println(thanhVien.toString());
            }
        }
    }

    public static void timThanhVien(ArrayList<nhanvien> arr, int mnv) {
        Scanner sc = new Scanner(System.in);
        boolean timThay = false;
        for (nhanvien thanhVien : arr) {
            if (thanhVien.getMnv() == mnv) {
                System.out.println("Thong tin thanh vien doi:");
                System.out.println(thanhVien.toString());
                timThay = true;
                break;
            }
        }

        if (!timThay) {
            System.out.println("Khong tim thay thanh vien với ma nhan vien " + mnv);
        }

    }
}
