package bai1;

import java.util.Scanner;

public class laptrinhvien extends nhanvien {
    int namkinhnghiem;

    public laptrinhvien() {
        super();
    }

    public laptrinhvien(int mnv, String hoten, int sonam) {
        super(mnv, hoten);
        this.namkinhnghiem = sonam;
        // TODO Auto-generated constructor stub
    }

    public int getNamkinhnghiem() {
        return namkinhnghiem;
    }

    public void setNamkinhnghiem(int namkinhnghiem) {
        this.namkinhnghiem = namkinhnghiem;
    }

    public void nhap_LTV() {
        Scanner sc = new Scanner(System.in);
        nhap_nhanvien();
        System.out.print("Nhap so nam kinh nghiem: ");
        this.namkinhnghiem = sc.nextInt();
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return super.toString() + "\t"+" nam kinh nghiem:" + this.namkinhnghiem;
    }
}
