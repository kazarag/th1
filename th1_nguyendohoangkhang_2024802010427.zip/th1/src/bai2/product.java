package bai2;

import java.util.Scanner;

public abstract class product {
    int masp;
    String tensp;
    double giagoc;

    abstract double giaban();

    public product() {
        super();
    }
    public product(int masp, String tensp) {
        this.masp = masp;
        this.tensp = tensp;
    }
    public product(int masp, String tensp, int giagoc) {
        this.masp = masp;
        this.tensp = tensp;
        this.giagoc = giagoc;
    }

    public int getmsp() {
        return masp;
    }

    public void setmasp(int masp) {
        this.masp = masp;
    }

    public String gettensp() {
        return tensp;
    }

    public void settensp(String tensp) {
        this.tensp = tensp;
    }

    public void nhap_sp() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap ma san pham: ");
        this.masp = sc.nextInt();
        sc.nextLine();
        System.out.print("Nhap ten san pham: ");
        this.tensp = sc.nextLine();
        System.out.print("Nhap gia goc san pham: ");
        this.giagoc = sc.nextInt();
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return this.masp + "\t" + this.tensp;
    }
}
