package bai2;

import java.util.Scanner;

public class phone extends product {
    public phone() {
        super();
    }

    public phone(int masp, String tensp) {
        super(masp, tensp);

        // TODO Auto-generated constructor stub
    }

    public void nhap_phone() {
        Scanner sc = new Scanner(System.in);
        nhap_sp();
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "Phone: " + super.toString()+"\t"+giaban();
    }

    @Override
    double giaban() {
        // TODO Auto-generated method stub
        return this.giagoc + this.giagoc *  0.1;
    }
}
